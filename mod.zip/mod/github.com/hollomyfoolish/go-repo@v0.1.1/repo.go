package repo

func Repo() string {
	return "github.com/hollomyfoolish/go-repo"
}