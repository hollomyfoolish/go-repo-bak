package s

import(
	"github.com/hollomyfoolish/go-repo/p2"
)

func SEcho() string {
	return "SEcho: " + p2.Echo()
}
