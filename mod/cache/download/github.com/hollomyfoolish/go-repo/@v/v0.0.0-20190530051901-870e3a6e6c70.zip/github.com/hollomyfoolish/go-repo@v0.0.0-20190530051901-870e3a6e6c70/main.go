package main

import(
	"fmt"
	"github.com/hollomyfoolish/go-repo/p2"
)

func main() {
	fmt.Printf("service: %s\n", p2.Echo())
}